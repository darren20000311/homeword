from stones import Stones
from intersections import Intersections

class GameController:
    def __init__(self, WINDOW_HEIGHT,WINDOW_WIDTH):
        self.WIDTH = WINDOW_WIDTH
        self.HEIGHT = WINDOW_HEIGHT
        self.all_occupied_game_over = False


    def update(self):
            self.all_occupied_game_over = True
            fill(255, 0, 0)
            textSize(30)
            text("GAME OVER", (self.WIDTH - textWidth("GAME OVER")) / 2, self.HEIGHT / 2)
