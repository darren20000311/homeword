import sys

def count_words_characters(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as file:
            content = file.read()
        words = content.split()
        characters = sum(len(word) for word in words)
        letter_and_number_count = sum(1 for char in content if char.isalnum())

        return len(words), characters, letter_and_number_count

    except OSError as e:
        return None

def main():
    file_name = input("Enter the file name:")
    counts = count_words_characters(file_name)

    if counts is not None:
        words, characters, letter_and_number_count = counts
        print("Words:", words)
        print(f"Characters: {characters}")
        print(f"Letters & numbers: {letter_and_number_count}")
    else:
        print(f"Can't open  {file_name}.")

main()